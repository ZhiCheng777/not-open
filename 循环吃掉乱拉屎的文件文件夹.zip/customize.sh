SKIPUNZIP=0

get_choose()
{
	local choose
	local branch
	while :; do
		choose="$(getevent -qlc 1 | awk '{ print $3 }')"
		case "$choose" in
		KEY_VOLUMEUP)  branch="0" ;;
		KEY_VOLUMEDOWN)  branch="1" ;;
		*)  continue ;;
		esac
		echo "$branch"
		break
	done
}

MyPrint() 
{
	echo "$@"
	sleep 0.03
}
MyPrint " "
MyPrint "(!) 安装说明："
MyPrint "- 安装完成重启后将默认删除/sdcard目录所有以.开头的文件夹/文件 以及其他无用文件夹"
MyPrint "- 先确认没有重要资料保存在/sdcard目录的以.开头的文件夹中 如果有请先备份后再安装刷入"
MyPrint " "
MyPrint "(?) 确认安装吗？(请选择)"
MyPrint "- 按音量键＋: 安装 √"
MyPrint "- 按音量键－: 退出 ×"
if [[ $(get_choose) == 0 ]]; then
	MyPrint "- 已选择安装"
	MyPrint " "
	if [[ -f /sdcard/Android/FUCK-XXX.conf ]]; then
		MyPrint "- 存在旧规则文件 是否保留原规则文件？(请选择)"
		MyPrint "- 按音量键＋: 保留"
		MyPrint "- 按音量键－: 替换"
		if [[ $(get_choose) == 1 ]]; then
			MyPrint "- 已选择替换备份原规则文件"
			cat /sdcard/Android/FUCK-XXX.conf > "/sdcard/Android/$(date "+%T")备份-FUCK-XXX.conf"
			MyPrint "- 已备份保存至/sdcard/Android/$(date "+%T")备份-FUCK-XXX.conf"
			rm -rf /sdcard/Android/FUCK-XXX.conf
			MyPrint "- 删除旧文件"
			cp -af $MODPATH/files/FUCK-XXX.conf /sdcard/Android/
			MyPrint "- 创建新文件"
			MyPrint " "
		else
			MyPrint "- 已选择保留原规则文件"
			MyPrint " "
		fi
	else
		MyPrint "- 创建规则文件至/sdcard/Android/ 重启后请打开该目录查看FUCK-XXX.conf"
		MyPrint " "
		cp -af $MODPATH/files/FUCK-XXX.conf /sdcard/Android/
	fi
	if [[ -d /data/adb/modules/FUCK-SHIT-FILE/files/*/ ]]; then
		MyPrint "- 存在次数记录信息"
		cp -af /data/adb/modules/FUCK-SHIT-FILE/files/*/ $MODPATH/files/
		MyPrint "- 复制信息"
		MyPrint " "
	fi
	if [[ "$(pm list package | grep -w 'com.tencent.monieqq')" != "" ]];then
		MyPrint "- 你安装了酷安 是否前往作者主页？(请选择)"
		MyPrint "- 按音量键＋: “前往”"
		MyPrint "- 按音量键－: “爷不去”"
		if [[ $(get_choose) == 0 ]]; then
			am start -d '1703597768@qq.com' >/dev/null 2>&1
			MyPrint "- 已完成"
			MyPrint " "
		else
			MyPrint "- 作者: “尼玛 我记住你了嗷”"
			MyPrint " "
		fi
	fi
else
	abort "- 已选择退出"
fi
